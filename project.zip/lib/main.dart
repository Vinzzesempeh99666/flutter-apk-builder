import 'package:flutter/material.dart';
import 'dashboard_download.dart';

void main() {
  runApp(const VinzDownloaderApp());
}

class VinzDownloaderApp extends StatelessWidget {
  const VinzDownloaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vinz Downloader',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050A14),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF22D3EE),
          secondary: Color(0xFF3B82F6),
          surface: Color(0xFF0B1220),
        ),
        fontFamily: 'Roboto',
      ),
      home: const DashboardDownload(),
    );
  }
}
