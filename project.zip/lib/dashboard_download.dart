import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

/// =====================================================================
/// Vinz Downloader — Dashboard Download
/// TikTok Video Downloader Tanpa Watermark
/// Fetch langsung ke API TikWM (sama seperti versi web/index.html),
/// lalu file di-download & disimpan ke penyimpanan HP (folder Download).
/// =====================================================================

const Color kBgDeep = Color(0xFF050A14);
const Color kBgPanel = Color(0xFF0B1220);
const Color kAccent = Color(0xFF22D3EE);
const Color kAccent2 = Color(0xFF3B82F6);
const Color kTextMain = Color(0xFFE6F1FF);
const Color kTextDim = Color(0xFF8AA0C2);
const Color kDanger = Color(0xFFF87171);
const Color kSuccess = Color(0xFF34D399);

const String kTikwmApi = "https://www.tikwm.com/api/";

class DashboardDownload extends StatefulWidget {
  const DashboardDownload({super.key});

  @override
  State<DashboardDownload> createState() => _DashboardDownloadState();
}

class _DashboardDownloadState extends State<DashboardDownload> {
  final TextEditingController _urlController = TextEditingController();
  final Dio _dio = Dio();

  bool _isLoading = false;
  String? _statusMessage;
  bool _isError = false;

  Map<String, dynamic>? _resultData;

  // Progress per-tombol (0-100), null = tidak sedang download
  int? _downloadingSD;
  int? _downloadingHD;
  int? _downloadingAudio;

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  bool _isValidTikTokUrl(String url) {
    final pattern = RegExp(r'(tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com)', caseSensitive: false);
    return pattern.hasMatch(url);
  }

  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData('text/plain');
    if (data?.text != null) {
      setState(() => _urlController.text = data!.text!);
    }
  }

  void _showStatus(String message, {bool isError = false}) {
    setState(() {
      _statusMessage = message;
      _isError = isError;
    });
  }

  void _hideStatus() {
    setState(() {
      _statusMessage = null;
    });
  }

  Future<void> _submitUrl() async {
    final url = _urlController.text.trim();

    if (url.isEmpty) {
      _showStatus('Masukkan link TikTok terlebih dahulu.', isError: true);
      return;
    }
    if (!_isValidTikTokUrl(url)) {
      _showStatus('Link TikTok tidak valid.', isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
      _resultData = null;
    });
    _hideStatus();

    try {
      final apiUrl = Uri.parse(
          '$kTikwmApi?url=${Uri.encodeComponent(url)}&hd=1');
      final response = await http.get(apiUrl);

      if (response.statusCode != 200) {
        throw Exception('HTTP ${response.statusCode}');
      }

      final json = jsonDecode(response.body);

      if (json['code'] != 0 || json['data'] == null) {
        _showStatus(json['msg'] ?? 'Gagal memproses video.', isError: true);
        setState(() => _isLoading = false);
        return;
      }

      setState(() {
        _resultData = json['data'];
        _isLoading = false;
      });
    } catch (e) {
      _showStatus('Terjadi kesalahan koneksi. Coba lagi beberapa saat.', isError: true);
      setState(() => _isLoading = false);
    }
  }

  String _fullUrl(String? path) {
    if (path == null || path.isEmpty) return '';
    if (path.startsWith('http')) return path;
    return 'https://www.tikwm.com$path';
  }

  /// Minta izin storage/photos sesuai versi Android
  Future<bool> _ensurePermission() async {
    if (!Platform.isAndroid) return true;

    // Android 13+ pakai photos/videos/audio permission,
    // Android <13 pakai storage permission.
    final storageStatus = await Permission.storage.status;
    final photosStatus = await Permission.photos.status;
    final videosStatus = await Permission.videos.status;

    if (storageStatus.isGranted || photosStatus.isGranted || videosStatus.isGranted) {
      return true;
    }

    final results = await [
      Permission.storage,
      Permission.photos,
      Permission.videos,
      Permission.audio,
    ].request();

    return results.values.any((status) => status.isGranted);
  }

  Future<Directory> _getDownloadDirectory() async {
    if (Platform.isAndroid) {
      // Folder Download publik di Android
      final dir = Directory('/storage/emulated/0/Download/VinzDownloader');
      if (!await dir.exists()) {
        await dir.create(recursive: true);
      }
      return dir;
    } else {
      final dir = await getApplicationDocumentsDirectory();
      final vinzDir = Directory('${dir.path}/VinzDownloader');
      if (!await vinzDir.exists()) {
        await vinzDir.create(recursive: true);
      }
      return vinzDir;
    }
  }

  Future<void> _downloadFile({
    required String url,
    required String filename,
    required void Function(int?) setProgress,
  }) async {
    if (url.isEmpty) {
      _showStatus('Link file tidak tersedia untuk opsi ini.', isError: true);
      return;
    }

    final hasPermission = await _ensurePermission();
    if (!hasPermission) {
      _showStatus(
        'Izin penyimpanan ditolak. Aktifkan izin di pengaturan aplikasi.',
        isError: true,
      );
      return;
    }

    setProgress(0);
    _hideStatus();

    try {
      final dir = await _getDownloadDirectory();
      final savePath = '${dir.path}/$filename';

      await _dio.download(
        url,
        savePath,
        onReceiveProgress: (received, total) {
          if (total > 0) {
            final percent = ((received / total) * 100).round();
            setProgress(percent);
          }
        },
      );

      setProgress(null);
      _showStatus('Tersimpan di: $savePath', isError: false);
    } catch (e) {
      setProgress(null);
      _showStatus('Gagal menyimpan file. Coba lagi.', isError: true);
    }
  }

  String _baseName() {
    final author = _resultData?['author'];
    String name = 'vinz';
    if (author != null) {
      name = author['unique_id'] ?? author['nickname'] ?? 'vinz';
    }
    return name.toString().replaceAll(RegExp(r'\s+'), '_');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(-0.6, -0.8),
            radius: 1.2,
            colors: [Color(0x2622D3EE), kBgDeep],
            stops: [0.0, 0.5],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildTopBar(),
                const SizedBox(height: 40),
                _buildHero(),
                const SizedBox(height: 16),
                _buildSearchBox(),
                const SizedBox(height: 16),
                _buildDownloadButton(),
                if (_statusMessage != null) ...[
                  const SizedBox(height: 16),
                  _buildStatusBox(),
                ],
                if (_resultData != null) ...[
                  const SizedBox(height: 24),
                  _buildResultCard(),
                ],
                const SizedBox(height: 40),
                _buildFooter(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(colors: [kAccent, kAccent2]),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset('assets/images/logo.jpg', fit: BoxFit.cover),
          ),
        ),
        const SizedBox(width: 10),
        RichText(
          text: const TextSpan(
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 18,
              color: kTextMain,
            ),
            children: [
              TextSpan(text: 'Vinz'),
              TextSpan(text: 'Downloader', style: TextStyle(color: kAccent)),
            ],
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: kSuccess.withOpacity(0.08),
            border: Border.all(color: kSuccess.withOpacity(0.3)),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 7,
                height: 7,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: kSuccess,
                ),
              ),
              const SizedBox(width: 6),
              const Text(
                'Server Aktif',
                style: TextStyle(fontSize: 12, color: kTextDim),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildHero() {
    return Column(
      children: [
        const Text(
          'Download Video TikTok',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w800,
            color: kTextMain,
            height: 1.25,
          ),
        ),
        const Text(
          'Tanpa Watermark',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w800,
            color: kAccent,
            height: 1.25,
          ),
        ),
        const SizedBox(height: 14),
        const Text(
          'Cepat, gratis, kualitas HD. Video dan audio tersimpan\nlangsung ke penyimpanan HP kamu.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 14, color: kTextDim, height: 1.4),
        ),
      ],
    );
  }

  Widget _buildSearchBox() {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: kBgPanel,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _urlController,
              style: const TextStyle(color: kTextMain, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Tempel tautan TikTok di sini...',
                hintStyle: TextStyle(color: kTextDim.withOpacity(0.7)),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              ),
            ),
          ),
          TextButton(
            onPressed: _pasteFromClipboard,
            style: TextButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.06),
              foregroundColor: kTextDim,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
            ),
            child: const Text('Tempel', style: TextStyle(fontSize: 13)),
          ),
        ],
      ),
    );
  }

  Widget _buildDownloadButton() {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton(
        onPressed: _isLoading ? null : _submitUrl,
        style: ElevatedButton.styleFrom(
          backgroundColor: kAccent,
          disabledBackgroundColor: kAccent.withOpacity(0.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          elevation: 0,
        ).copyWith(
          backgroundColor: WidgetStateProperty.resolveWith((states) {
            return null; // gradient dihandle via Ink di bawah
          }),
        ),
        child: Ink(
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [kAccent, kAccent2]),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Container(
            alignment: Alignment.center,
            child: _isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.4,
                      color: Color(0xFF04101C),
                    ),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.download_rounded, color: Color(0xFF04101C)),
                      SizedBox(width: 8),
                      Text(
                        'Download',
                        style: TextStyle(
                          color: Color(0xFF04101C),
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBox() {
    final color = _isError ? kDanger : const Color(0xFF93C5FD);
    final bg = _isError ? kDanger.withOpacity(0.1) : kAccent2.withOpacity(0.1);
    final border = _isError ? kDanger.withOpacity(0.3) : kAccent2.withOpacity(0.3);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: bg,
        border: Border.all(color: border),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        _statusMessage!,
        style: TextStyle(color: color, fontSize: 13.5),
      ),
    );
  }

  Widget _buildResultCard() {
    final data = _resultData!;
    final cover = data['cover'] ?? data['origin_cover'] ?? '';
    final title = data['title'] ?? 'No description';
    final author = data['author'];
    final authorName = author != null
        ? '@${author['unique_id'] ?? author['nickname'] ?? 'unknown'}'
        : '@unknown';

    final noWM = _fullUrl(data['play']);
    final hd = _fullUrl(data['hdplay']);
    final music = _fullUrl(data['music']);
    final base = _baseName();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kBgPanel,
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: cover.isNotEmpty
                    ? Image.network(
                        cover,
                        width: 64,
                        height: 64,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 64,
                          height: 64,
                          color: Colors.black26,
                        ),
                      )
                    : Container(width: 64, height: 64, color: Colors.black26),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: kTextMain,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      authorName,
                      style: const TextStyle(fontSize: 13, color: kTextDim),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildDlButton(
            label: 'Download Tanpa Watermark',
            icon: Icons.file_download_outlined,
            primary: true,
            progress: _downloadingSD,
            onTap: () => _downloadFile(
              url: noWM,
              filename: '${base}_sd_${DateTime.now().millisecondsSinceEpoch}.mp4',
              setProgress: (v) => setState(() => _downloadingSD = v),
            ),
          ),
          const SizedBox(height: 10),
          _buildDlButton(
            label: 'Download HD',
            icon: Icons.high_quality_outlined,
            primary: false,
            progress: _downloadingHD,
            onTap: hd.isEmpty
                ? null
                : () => _downloadFile(
                      url: hd,
                      filename: '${base}_hd_${DateTime.now().millisecondsSinceEpoch}.mp4',
                      setProgress: (v) => setState(() => _downloadingHD = v),
                    ),
          ),
          const SizedBox(height: 10),
          _buildDlButton(
            label: 'Download Audio (MP3)',
            icon: Icons.music_note_outlined,
            primary: false,
            progress: _downloadingAudio,
            onTap: music.isEmpty
                ? null
                : () => _downloadFile(
                      url: music,
                      filename: '${base}_audio_${DateTime.now().millisecondsSinceEpoch}.mp3',
                      setProgress: (v) => setState(() => _downloadingAudio = v),
                    ),
          ),
          const SizedBox(height: 14),
          Center(
            child: TextButton(
              onPressed: () {
                setState(() {
                  _resultData = null;
                  _urlController.clear();
                });
                _hideStatus();
              },
              child: const Text(
                'Cari video lain',
                style: TextStyle(color: kTextDim, decoration: TextDecoration.underline),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDlButton({
    required String label,
    required IconData icon,
    required bool primary,
    required int? progress,
    required VoidCallback? onTap,
  }) {
    final isBusy = progress != null;

    return SizedBox(
      width: double.infinity,
      height: 48,
      child: OutlinedButton(
        onPressed: (isBusy || onTap == null) ? null : onTap,
        style: OutlinedButton.styleFrom(
          backgroundColor: primary ? null : Colors.white.withOpacity(0.04),
          side: BorderSide(color: Colors.white.withOpacity(0.1)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        child: Container(
          decoration: primary
              ? BoxDecoration(
                  gradient: const LinearGradient(colors: [kAccent, kAccent2]),
                  borderRadius: BorderRadius.circular(9),
                )
              : null,
          alignment: Alignment.center,
          child: isBusy
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: primary ? const Color(0xFF04101C) : kAccent,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '$progress%',
                      style: TextStyle(
                        color: primary ? const Color(0xFF04101C) : kTextMain,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, size: 18, color: primary ? const Color(0xFF04101C) : kTextMain),
                    const SizedBox(width: 8),
                    Text(
                      label,
                      style: TextStyle(
                        color: primary ? const Color(0xFF04101C) : kTextMain,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return const Center(
      child: Text(
        'Vinz Downloader · Video & audio tersimpan ke penyimpanan HP',
        style: TextStyle(fontSize: 12, color: kTextDim),
      ),
    );
  }
}
