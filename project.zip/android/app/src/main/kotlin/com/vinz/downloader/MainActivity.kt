package com.vinz.downloader

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
