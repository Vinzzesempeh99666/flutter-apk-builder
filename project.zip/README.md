# Vinz Downloader — Base Flutter

TikTok Video Downloader Tanpa Watermark. Fetch langsung ke API TikWM
(sama seperti versi web), lalu file didownload & disimpan ke folder
`Download/VinzDownloader` di penyimpanan HP.

Project ini **sudah lengkap dengan folder `android/`** (Gradle, Manifest,
permission, launcher icon) — jadi tinggal buka & build, tidak perlu bikin
project baru dari nol.

## Cara Pakai

1. Extract ZIP ini, buka foldernya pakai **Android Studio** atau VS Code.

2. Rename `android/local.properties.example` jadi `android/local.properties`,
   lalu sesuaikan path `sdk.dir` dan `flutter.sdk` dengan lokasi SDK di
   komputer kamu. (Kalau buka pakai Android Studio, biasanya file ini
   otomatis dibuat/diisi sendiri saat project di-sync — cek dulu apakah
   sudah ada sebelum bikin manual.)

3. Jalankan:
   ```
   flutter pub get
   flutter run
   ```
   atau build APK:
   ```
   flutter build apk --release
   ```

Permission storage/media, launcher icon, dan AndroidManifest **sudah
ditanam otomatis** di project ini — tidak perlu edit manual lagi.

## Struktur

```
lib/
  main.dart                 -> entry point, tema cyberpunk
  dashboard_download.dart   -> UI + logika downloader TikTok
assets/
  images/logo.jpg           -> logo & app icon
android/
  app/src/main/AndroidManifest.xml   -> permission sudah lengkap
  app/src/main/res/mipmap-*/         -> launcher icon (generate dari logo)
  app/build.gradle.kts                -> namespace: com.vinz.downloader
```

## Fitur

- Paste link TikTok, fetch metadata dari TikWM API
- Preview cover, judul, dan username
- 3 tombol download:
  - Download Tanpa Watermark (SD)
  - Download HD
  - Download Audio (MP3)
- Semua file tersimpan otomatis ke `Download/VinzDownloader` di penyimpanan HP
- Progress bar per tombol saat proses download
- Request permission storage otomatis (support Android lama & baru)

## Kalau Mau Ganti Nama Package / Application ID

Sekarang package name-nya `com.vinz.downloader`. Kalau mau ganti:
1. Ganti `namespace` dan `applicationId` di `android/app/build.gradle.kts`
2. Ganti folder `android/app/src/main/kotlin/com/vinz/downloader/` sesuai
   package baru (folder harus cocok dengan applicationId)
3. Update `package com.vinz.downloader` di `MainActivity.kt`

## Catatan

- Logo yang dipakai (`assets/images/logo.jpg`) adalah file yang kamu upload
  sendiri — pastikan kamu punya hak pakai untuk gambar tersebut sebelum
  dipublikasikan ke Play Store, karena gambar mengandung karakter anime
  (One Piece) yang punya hak cipta sendiri. Untuk keperluan pribadi/testing
  biasanya aman, tapi untuk rilis publik sebaiknya ganti dengan logo original.
